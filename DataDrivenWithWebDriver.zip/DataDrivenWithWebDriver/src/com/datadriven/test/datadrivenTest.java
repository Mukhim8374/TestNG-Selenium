package com.datadriven.test;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

import com.excel.utility.Xls_Reader;

public class datadrivenTest {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		
		Xls_Reader reader= new Xls_Reader("D:\\workspace\\DataDrivenWithWebDriver\\src\\com\\testdata\\TestData.xlsx");
		
		String firstname = reader.getCellData("Sheet1", "FirsName", 3);
		System.out.println(firstname);
		
		
		String lastname = reader.getCellData("Sheet1", "LastName", 3);
		System.out.println(lastname);
		
		
		System.setProperty("webdriver.chrome.driver", "C:\\Users\\Mukhim\\Pictures\\Chrome Downloads\\chromedriver_win32 (2)\\chromedriver.exe");
		
		WebDriver driver = new ChromeDriver();
		driver.manage().window().maximize();
		driver.manage().deleteAllCookies();
		driver.get("http://demo.automationtesting.in/Register.html");
		
		driver.findElement(By.xpath("//input[@placeholder='First Name']")).sendKeys(firstname);
		driver.findElement(By.xpath("//input[@placeholder='Last Name']")).sendKeys(lastname);
	}

}
