package com.test.util;

import java.util.ArrayList;

import com.excel.utility.Xls_Reader;

public class TestUtil {
	
	public static ArrayList<Object[]> getTestData() {
		
		ArrayList<Object[]> myData = new ArrayList<Object[]>();
		
		Xls_Reader reader = new Xls_Reader("D:\\workspace\\DataDrivenWithTestNG\\src\\com\\testData\\TestData.xlsx");
		
		
		for (int rowNum	=2; rowNum<=reader.getRowCount("Sheet1"); rowNum++) {
			
			String firstName = reader.getCellData("Sheet1", "FirsName", rowNum);
			String lastName = reader.getCellData("Sheet1", "LastName", rowNum);
			String Phone = reader.getCellData("Sheet1", "MobileNumber", rowNum);
			String password = reader.getCellData("Sheet1", "PassWord", rowNum);
			String email = reader.getCellData("Sheet1", "email", rowNum);
			String address = reader.getCellData("Sheet1", "Address", rowNum);
			
			
			Object ob[] = {firstName,lastName,Phone, password, email, address};
			myData.add(ob);			
		}
		
		return myData;
		
		
		
		
		
	}

	
}
