package com.datadriven.test;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

import com.excel.utility.Xls_Reader;

public class datadrivenTest {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		System.setProperty("webdriver.chrome.driver", "C:\\Users\\Mukhim\\Pictures\\Chrome Downloads\\chromedriver_win32 (2)\\chromedriver.exe");
		
		WebDriver driver = new ChromeDriver();
		driver.manage().window().maximize();
		driver.manage().deleteAllCookies();
		driver.get("http://demo.automationtesting.in/Register.html");
		
		WebElement FName=driver.findElement(By.xpath("//input[@placeholder='First Name']"));
		WebElement LName=driver.findElement(By.xpath("//input[@placeholder='Last Name']"));
		Xls_Reader reader= new Xls_Reader("D:\\workspace\\DataDrivenWithWebDriver\\src\\com\\testdata\\TestData.xlsx");
		
		int rowCount = reader.getRowCount("Sheet1");
		
		for(int rowNum=2 ; rowNum<rowCount; rowNum++) {
			
			String firstname = reader.getCellData("Sheet1", "FirsName", rowNum);
			String lastname = reader.getCellData("Sheet1", "LastName", rowNum);
			
			FName.clear();
			FName.sendKeys(firstname);
			
			LName.clear();
			LName.sendKeys(lastname);
			
			
			
			
//			driver.close();
		}
		
		
	}

}
